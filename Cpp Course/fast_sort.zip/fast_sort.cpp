/***************************************************************************
 *
 * Username:
 * Full name:
 * Date:
 *
 **************************************************************************/

// include any headers needed

using namespace std;

// Keep up good habits with any "magic numbers"
// e.g. names are not longer than 14 characters

// declare any struct(s) here

// function prototype declarations

int main(void){

	// read in the input and output filenames

	// count the number of records in the file by reading them in
	// reset the input file status after reading to the end
	// rewind the file using seekg()

	// create an array (of structs) to hold all persons in the file
	// do you need any other arrays?

	// read the data for real this time

	// print out the unsorted list

	// Now sort either on first_name, second_name or mobile number
	// ask the question again if the user does not give a valid answer

	// call your sorting function (it needs to be fast...)

	// now print out the sorted list

	// remember to tidy up any dynamical memory allocations, close any
	// open files etc.	

}		// end of main()

// function definitions here
