/**************************************************************************************
 *
 *	Username:	
 *	Name:		
 *	Date:
 *
 *************************************************************************************/
// include all headers needed here

// write the structure declaration here

// prototype function declaration(s)

int main(){

	// read the input and output filenames

	// declare array of structs, open input file and read sets of 3 numbers
	// (x, y sigma) into array

	// close the input file and open the output file

	// compute fit parameters and errors, using a struct to collect the weighted sums

	// write to output file and close it

}		

// function definition(s) here
