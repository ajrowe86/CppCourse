/**************************************************************************************
 *
 *	Username:	
 *	Name:		
 *	Date:
 *
 *************************************************************************************/
// include all headers needed here

// prototype function declaration(s)

int main(){

	// read the input and output filenames

	// declare arrays, open input file and read numbers into arrays

	// close the input file and open the output file

	// compute fit parameters and errors

	// write to output file and close it

}		

// function definition(s) here
